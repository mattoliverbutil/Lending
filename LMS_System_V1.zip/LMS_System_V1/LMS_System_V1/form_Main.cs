﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MaterialSkin;
using MaterialSkin.Animations;
using MaterialSkin.Controls;
using System.Threading;

namespace LMS_System_V1
{
    public partial class form_Main : MaterialSkin.Controls.MaterialForm
    {
        public form_Main()
        {
            InitializeComponent();
            InitializeComponent();
            MaterialSkin.MaterialSkinManager skinManager = MaterialSkin.MaterialSkinManager.Instance;
            skinManager.AddFormToManage(this);
            skinManager.Theme = MaterialSkin.MaterialSkinManager.Themes.LIGHT;
            skinManager.ColorScheme = new MaterialSkin.ColorScheme(MaterialSkin.Primary.Green600, MaterialSkin.Primary.BlueGrey900, MaterialSkin.Primary.BlueGrey500, MaterialSkin.Accent.Orange700, MaterialSkin.TextShade.WHITE);
        }

        private void btn_Logout_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Do you want to Logout?", "[ Confirmation Message ]",
            MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (result == DialogResult.Yes)
            {
                form_Login login = new form_Login();
                login.Show();
                this.Hide();
            }
            else if (result == DialogResult.No)
            {
                //code for No
            }
        }

        private void form_Main_Load(object sender, EventArgs e)
        {
            
        }

        private void btn_ViewClients_Click(object sender, EventArgs e)
        {
            form_Clients viewlist = new form_Clients();
            viewlist.Show();
            this.Hide();
        }
    }
}
