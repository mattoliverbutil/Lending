﻿namespace LMS_System_V1
{
    partial class form_Clients
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btn_GoBackMainMenu = new MetroFramework.Controls.MetroButton();
            this.Save = new MetroFramework.Controls.MetroTile();
            this.mtDelete = new MetroFramework.Controls.MetroTile();
            this.mtEdit = new MetroFramework.Controls.MetroTile();
            this.mtAdd = new MetroFramework.Controls.MetroTile();
            this.cboSearchCategories = new MetroFramework.Controls.MetroComboBox();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.txtbxSeach = new MetroFramework.Controls.MetroTextBox();
            this.clientIdDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lastNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.firstNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.genderIdDataGridViewComboBox = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.genderKindBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.emailAddressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clientBindingSource = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.genderKindBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.clientBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeColumns = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.clientIdDataGridViewTextBoxColumn,
            this.lastNameDataGridViewTextBoxColumn,
            this.firstNameDataGridViewTextBoxColumn,
            this.genderIdDataGridViewComboBox,
            this.emailAddressDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.clientBindingSource;
            this.dataGridView1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.dataGridView1.Location = new System.Drawing.Point(24, 262);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dataGridView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.dataGridView1.RowTemplate.ReadOnly = true;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(980, 277);
            this.dataGridView1.TabIndex = 5;
            this.dataGridView1.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellDoubleClick);
            // 
            // btn_GoBackMainMenu
            // 
            this.btn_GoBackMainMenu.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_GoBackMainMenu.Location = new System.Drawing.Point(856, 556);
            this.btn_GoBackMainMenu.Name = "btn_GoBackMainMenu";
            this.btn_GoBackMainMenu.Size = new System.Drawing.Size(146, 23);
            this.btn_GoBackMainMenu.TabIndex = 7;
            this.btn_GoBackMainMenu.Text = "Go Back to Main Menu";
            this.btn_GoBackMainMenu.Click += new System.EventHandler(this.btn_GoBackMainMenu_Click_1);
            // 
            // Save
            // 
            this.Save.Location = new System.Drawing.Point(324, 91);
            this.Save.Name = "Save";
            this.Save.Size = new System.Drawing.Size(94, 82);
            this.Save.TabIndex = 4;
            this.Save.Text = "Save";
            this.Save.TileImage = global::LMS_System_V1.Properties.Resources.save_icon;
            this.Save.TileImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Save.UseTileImage = true;
            this.Save.Click += new System.EventHandler(this.Save_Click);
            // 
            // mtDelete
            // 
            this.mtDelete.Location = new System.Drawing.Point(224, 91);
            this.mtDelete.Name = "mtDelete";
            this.mtDelete.Size = new System.Drawing.Size(94, 82);
            this.mtDelete.TabIndex = 3;
            this.mtDelete.Text = "Delete";
            this.mtDelete.TileImage = global::LMS_System_V1.Properties.Resources.delete_icon;
            this.mtDelete.TileImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.mtDelete.UseTileImage = true;
            this.mtDelete.Click += new System.EventHandler(this.mtDelete_Click);
            // 
            // mtEdit
            // 
            this.mtEdit.Location = new System.Drawing.Point(124, 91);
            this.mtEdit.Name = "mtEdit";
            this.mtEdit.Size = new System.Drawing.Size(94, 82);
            this.mtEdit.TabIndex = 2;
            this.mtEdit.Text = "Edit";
            this.mtEdit.TileImage = global::LMS_System_V1.Properties.Resources.edit_icon;
            this.mtEdit.TileImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.mtEdit.UseTileImage = true;
            this.mtEdit.Click += new System.EventHandler(this.mtEdit_Click);
            // 
            // mtAdd
            // 
            this.mtAdd.Location = new System.Drawing.Point(24, 91);
            this.mtAdd.Name = "mtAdd";
            this.mtAdd.Size = new System.Drawing.Size(94, 82);
            this.mtAdd.TabIndex = 1;
            this.mtAdd.Text = "Add";
            this.mtAdd.TileImage = global::LMS_System_V1.Properties.Resources.add_icon;
            this.mtAdd.TileImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.mtAdd.UseTileImage = true;
            this.mtAdd.Click += new System.EventHandler(this.mtAdd_Click);
            // 
            // cboSearchCategories
            // 
            this.cboSearchCategories.FormattingEnabled = true;
            this.cboSearchCategories.ItemHeight = 23;
            this.cboSearchCategories.Items.AddRange(new object[] {
            "ClientId",
            "LastName",
            "FirstName"});
            this.cboSearchCategories.Location = new System.Drawing.Point(24, 205);
            this.cboSearchCategories.Name = "cboSearchCategories";
            this.cboSearchCategories.Size = new System.Drawing.Size(294, 29);
            this.cboSearchCategories.TabIndex = 8;
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(359, 209);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(59, 19);
            this.metroLabel1.TabIndex = 9;
            this.metroLabel1.Text = "Search : ";
            // 
            // txtbxSeach
            // 
            this.txtbxSeach.Location = new System.Drawing.Point(436, 205);
            this.txtbxSeach.Name = "txtbxSeach";
            this.txtbxSeach.Size = new System.Drawing.Size(372, 23);
            this.txtbxSeach.TabIndex = 10;
            this.txtbxSeach.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtbxSeach_KeyDown);
            // 
            // clientIdDataGridViewTextBoxColumn
            // 
            this.clientIdDataGridViewTextBoxColumn.DataPropertyName = "ClientId";
            this.clientIdDataGridViewTextBoxColumn.HeaderText = "Client ID";
            this.clientIdDataGridViewTextBoxColumn.Name = "clientIdDataGridViewTextBoxColumn";
            this.clientIdDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // lastNameDataGridViewTextBoxColumn
            // 
            this.lastNameDataGridViewTextBoxColumn.DataPropertyName = "LastName";
            this.lastNameDataGridViewTextBoxColumn.HeaderText = "Last Name";
            this.lastNameDataGridViewTextBoxColumn.Name = "lastNameDataGridViewTextBoxColumn";
            this.lastNameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // firstNameDataGridViewTextBoxColumn
            // 
            this.firstNameDataGridViewTextBoxColumn.DataPropertyName = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.HeaderText = "First Name";
            this.firstNameDataGridViewTextBoxColumn.Name = "firstNameDataGridViewTextBoxColumn";
            this.firstNameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // genderIdDataGridViewComboBox
            // 
            this.genderIdDataGridViewComboBox.DataPropertyName = "GenderId";
            this.genderIdDataGridViewComboBox.DataSource = this.genderKindBindingSource;
            this.genderIdDataGridViewComboBox.DisplayMember = "GenderMaleFemale";
            this.genderIdDataGridViewComboBox.HeaderText = "Gender";
            this.genderIdDataGridViewComboBox.Name = "genderIdDataGridViewComboBox";
            this.genderIdDataGridViewComboBox.ReadOnly = true;
            this.genderIdDataGridViewComboBox.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.genderIdDataGridViewComboBox.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.genderIdDataGridViewComboBox.ValueMember = "GenderId";
            // 
            // genderKindBindingSource
            // 
            this.genderKindBindingSource.DataSource = typeof(LMS_System_V1.GenderKind);
            // 
            // emailAddressDataGridViewTextBoxColumn
            // 
            this.emailAddressDataGridViewTextBoxColumn.DataPropertyName = "EmailAddress";
            this.emailAddressDataGridViewTextBoxColumn.HeaderText = "Email Address";
            this.emailAddressDataGridViewTextBoxColumn.Name = "emailAddressDataGridViewTextBoxColumn";
            this.emailAddressDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // clientBindingSource
            // 
            this.clientBindingSource.DataSource = typeof(LMS_System_V1.Client);
            // 
            // form_Clients
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1025, 602);
            this.Controls.Add(this.txtbxSeach);
            this.Controls.Add(this.metroLabel1);
            this.Controls.Add(this.cboSearchCategories);
            this.Controls.Add(this.btn_GoBackMainMenu);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.Save);
            this.Controls.Add(this.mtDelete);
            this.Controls.Add(this.mtEdit);
            this.Controls.Add(this.mtAdd);
            this.Name = "form_Clients";
            this.Text = "[ Client\'s Viewlist ]";
            this.Load += new System.EventHandler(this.form_Clients_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.genderKindBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.clientBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroTile mtAdd;
        private MetroFramework.Controls.MetroTile mtEdit;
        private MetroFramework.Controls.MetroTile mtDelete;
        private MetroFramework.Controls.MetroTile Save;
        private System.Windows.Forms.DataGridView dataGridView1;
        private MetroFramework.Controls.MetroButton btn_GoBackMainMenu;
        private System.Windows.Forms.BindingSource genderKindBindingSource;
        private System.Windows.Forms.BindingSource clientBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn clientIdDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lastNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn firstNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn genderIdDataGridViewComboBox;
        private System.Windows.Forms.DataGridViewTextBoxColumn emailAddressDataGridViewTextBoxColumn;
        private MetroFramework.Controls.MetroComboBox cboSearchCategories;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        public MetroFramework.Controls.MetroTextBox txtbxSeach;

    }
}