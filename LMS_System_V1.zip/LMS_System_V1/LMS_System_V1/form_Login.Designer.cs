﻿namespace LMS_System_V1
{
    partial class form_Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtbx_Username = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.txtbx_Password = new MaterialSkin.Controls.MaterialSingleLineTextField();
            this.btn_Login = new MaterialSkin.Controls.MaterialRaisedButton();
            this.Label_Username = new MaterialSkin.Controls.MaterialLabel();
            this.Label_Password = new MaterialSkin.Controls.MaterialLabel();
            this.btn_Exit = new MaterialSkin.Controls.MaterialRaisedButton();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.chkbx_Show_Hide_Password = new MaterialSkin.Controls.MaterialCheckBox();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtbx_Username
            // 
            this.txtbx_Username.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtbx_Username.Depth = 0;
            this.txtbx_Username.Hint = "";
            this.txtbx_Username.Location = new System.Drawing.Point(61, 123);
            this.txtbx_Username.MouseState = MaterialSkin.MouseState.HOVER;
            this.txtbx_Username.Name = "txtbx_Username";
            this.txtbx_Username.PasswordChar = '\0';
            this.txtbx_Username.SelectedText = "";
            this.txtbx_Username.SelectionLength = 0;
            this.txtbx_Username.SelectionStart = 0;
            this.txtbx_Username.Size = new System.Drawing.Size(402, 23);
            this.txtbx_Username.TabIndex = 0;
            this.txtbx_Username.UseSystemPasswordChar = false;
            this.txtbx_Username.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtbx_Username_KeyPress);
            this.txtbx_Username.MouseHover += new System.EventHandler(this.txtbx_Username_MouseHover);
            this.txtbx_Username.MouseLeave += new System.EventHandler(this.txtbx_Username_MouseLeave);
            // 
            // txtbx_Password
            // 
            this.txtbx_Password.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtbx_Password.Depth = 0;
            this.txtbx_Password.Hint = "";
            this.txtbx_Password.Location = new System.Drawing.Point(62, 196);
            this.txtbx_Password.MouseState = MaterialSkin.MouseState.HOVER;
            this.txtbx_Password.Name = "txtbx_Password";
            this.txtbx_Password.PasswordChar = '\0';
            this.txtbx_Password.SelectedText = "";
            this.txtbx_Password.SelectionLength = 0;
            this.txtbx_Password.SelectionStart = 0;
            this.txtbx_Password.Size = new System.Drawing.Size(402, 23);
            this.txtbx_Password.TabIndex = 1;
            this.txtbx_Password.UseSystemPasswordChar = true;
            this.txtbx_Password.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtbx_Password_KeyPress);
            this.txtbx_Password.MouseHover += new System.EventHandler(this.txtbx_Password_MouseHover);
            this.txtbx_Password.MouseLeave += new System.EventHandler(this.txtbx_Password_MouseLeave);
            // 
            // btn_Login
            // 
            this.btn_Login.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_Login.Depth = 0;
            this.btn_Login.Location = new System.Drawing.Point(212, 277);
            this.btn_Login.MouseState = MaterialSkin.MouseState.HOVER;
            this.btn_Login.Name = "btn_Login";
            this.btn_Login.Primary = true;
            this.btn_Login.Size = new System.Drawing.Size(117, 30);
            this.btn_Login.TabIndex = 2;
            this.btn_Login.Text = "Login";
            this.btn_Login.UseVisualStyleBackColor = true;
            this.btn_Login.Click += new System.EventHandler(this.btn_Login_Click);
            this.btn_Login.MouseLeave += new System.EventHandler(this.btn_Login_MouseLeave);
            this.btn_Login.MouseHover += new System.EventHandler(this.btn_Login_MouseHover);
            // 
            // Label_Username
            // 
            this.Label_Username.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Label_Username.AutoSize = true;
            this.Label_Username.Depth = 0;
            this.Label_Username.Font = new System.Drawing.Font("Roboto", 11F);
            this.Label_Username.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Label_Username.Location = new System.Drawing.Point(58, 102);
            this.Label_Username.MouseState = MaterialSkin.MouseState.HOVER;
            this.Label_Username.Name = "Label_Username";
            this.Label_Username.Size = new System.Drawing.Size(77, 19);
            this.Label_Username.TabIndex = 3;
            this.Label_Username.Text = "Username";
            // 
            // Label_Password
            // 
            this.Label_Password.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Label_Password.AutoSize = true;
            this.Label_Password.Depth = 0;
            this.Label_Password.Font = new System.Drawing.Font("Roboto", 11F);
            this.Label_Password.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Label_Password.Location = new System.Drawing.Point(59, 174);
            this.Label_Password.MouseState = MaterialSkin.MouseState.HOVER;
            this.Label_Password.Name = "Label_Password";
            this.Label_Password.Size = new System.Drawing.Size(75, 19);
            this.Label_Password.TabIndex = 4;
            this.Label_Password.Text = "Password";
            // 
            // btn_Exit
            // 
            this.btn_Exit.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_Exit.Depth = 0;
            this.btn_Exit.Location = new System.Drawing.Point(347, 277);
            this.btn_Exit.MouseState = MaterialSkin.MouseState.HOVER;
            this.btn_Exit.Name = "btn_Exit";
            this.btn_Exit.Primary = true;
            this.btn_Exit.Size = new System.Drawing.Size(117, 30);
            this.btn_Exit.TabIndex = 3;
            this.btn_Exit.Text = "Exit";
            this.btn_Exit.UseVisualStyleBackColor = true;
            this.btn_Exit.Click += new System.EventHandler(this.btn_Exit_Click);
            this.btn_Exit.MouseLeave += new System.EventHandler(this.btn_Exit_MouseLeave);
            this.btn_Exit.MouseHover += new System.EventHandler(this.btn_Exit_MouseHover);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 341);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(517, 22);
            this.statusStrip1.TabIndex = 6;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(0, 17);
            // 
            // chkbx_Show_Hide_Password
            // 
            this.chkbx_Show_Hide_Password.AutoSize = true;
            this.chkbx_Show_Hide_Password.Depth = 0;
            this.chkbx_Show_Hide_Password.Font = new System.Drawing.Font("Roboto", 10F);
            this.chkbx_Show_Hide_Password.Location = new System.Drawing.Point(61, 232);
            this.chkbx_Show_Hide_Password.Margin = new System.Windows.Forms.Padding(0);
            this.chkbx_Show_Hide_Password.MouseLocation = new System.Drawing.Point(-1, -1);
            this.chkbx_Show_Hide_Password.MouseState = MaterialSkin.MouseState.HOVER;
            this.chkbx_Show_Hide_Password.Name = "chkbx_Show_Hide_Password";
            this.chkbx_Show_Hide_Password.Ripple = true;
            this.chkbx_Show_Hide_Password.Size = new System.Drawing.Size(128, 30);
            this.chkbx_Show_Hide_Password.TabIndex = 7;
            this.chkbx_Show_Hide_Password.Text = "Show Password";
            this.chkbx_Show_Hide_Password.UseVisualStyleBackColor = true;
            this.chkbx_Show_Hide_Password.CheckedChanged += new System.EventHandler(this.chkbx_Show_Hide_Password_CheckedChanged);
            // 
            // form_Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(517, 363);
            this.Controls.Add(this.chkbx_Show_Hide_Password);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.btn_Exit);
            this.Controls.Add(this.Label_Password);
            this.Controls.Add(this.Label_Username);
            this.Controls.Add(this.btn_Login);
            this.Controls.Add(this.txtbx_Password);
            this.Controls.Add(this.txtbx_Username);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "form_Login";
            this.Sizable = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "[ Login ]";
            this.Load += new System.EventHandler(this.form_Login_Load);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MaterialSkin.Controls.MaterialSingleLineTextField txtbx_Username;
        private MaterialSkin.Controls.MaterialSingleLineTextField txtbx_Password;
        private MaterialSkin.Controls.MaterialRaisedButton btn_Login;
        private MaterialSkin.Controls.MaterialLabel Label_Username;
        private MaterialSkin.Controls.MaterialLabel Label_Password;
        private MaterialSkin.Controls.MaterialRaisedButton btn_Exit;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private MaterialSkin.Controls.MaterialCheckBox chkbx_Show_Hide_Password;
    }
}