﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LMS_System_V1
{
    public partial class form_ClientsTransactions : MetroFramework.Forms.MetroForm
    {
        public form_ClientsTransactions()
        {
            InitializeComponent();
            
        }

        private void btnPrintPreview_Click(object sender, EventArgs e)
        {
            ClientInfosPrintPreviewDialog.Document = ClientInfosPrintDocument;
            ClientInfosPrintPreviewDialog.ShowDialog();
        }

        private void ClientInfosPrintDocument_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {

            Bitmap bmp = Properties.Resources.PRINT_PREVIEW_TEMPORARY_LOGO;
            Image newImage = bmp;
            e.Graphics.DrawImage(newImage, 25, 25, newImage.Width, newImage.Height);

            e.Graphics.DrawString("Client ID : " + mtbox1.Text + "", new Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(50, 290));
            e.Graphics.DrawString("Last Name : " + mtbox2.Text + "", new Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(50, 350));
            e.Graphics.DrawString("First Name : " + mtbox3.Text + "", new Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(250, 350));
            e.Graphics.DrawString("Middle Name : " + mtbox4.Text + "", new Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(450, 350));
        }

        private void metroLabel14_Click(object sender, EventArgs e)
        {

        }
    }
}
