﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LMS_System_V1
{
    public partial class form_ClientsInfos : MetroFramework.Forms.MetroForm
    {
        public form_ClientsInfos(Client obj)
        {
            InitializeComponent();
            bindingSourceClient.DataSource = obj;
        }

        public Client ClientInfo { get { return bindingSourceClient.Current as Client; } }

        private void btnSave_Click(object sender, EventArgs e)
        {
            bindingSourceClient.EndEdit();
            DialogResult = DialogResult.OK;
        }

        private void form_ClientsInfos_Load(object sender, EventArgs e)
        {
            cboGender.DisplayMember = "GenderName";
            cboGender.ValueMember = "GenderId";

            using (DbEntities db = new DbEntities())
            {
                cboGender.DataSource = db.GenderKinds.ToList();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void btnPrintPreview_Click(object sender, EventArgs e)
        {
            ClientInfoPreviewDialog.Document = ClientInfoPrintDocument;
            ClientInfoPreviewDialog.ShowDialog();
        }

        private void ClientInfoPrintDocument_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            Bitmap bmp = Properties.Resources.PRINT_PREVIEW_TEMPORARY_LOGO;
            Image newImage = bmp;
            e.Graphics.DrawImage(newImage, 25, 25, newImage.Width, newImage.Height);

            e.Graphics.DrawString("Client ID : " + metroTextBox1.Text + "", new Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(50, 290));
            e.Graphics.DrawString("Last Name : " + txtLastName.Text + "", new Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(50, 350));
            e.Graphics.DrawString("First Name : " + txtFirstName.Text + "", new Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(250, 350));
            e.Graphics.DrawString("Middle Name : " + txtMiddleName.Text + "", new Font("Arial", 12, FontStyle.Bold), Brushes.Black, new Point(450, 350));

        }
    }

}