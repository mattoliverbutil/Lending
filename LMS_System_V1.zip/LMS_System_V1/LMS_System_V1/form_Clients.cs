﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LMS_System_V1
{
    public partial class form_Clients : MetroFramework.Forms.MetroForm
    {
        public form_Clients()
        {
            InitializeComponent();
        }

        //ADD BUTTON
        private async void mtAdd_Click(object sender, EventArgs e)
        {
            using (form_ClientsInfos infos = new form_ClientsInfos(new Client()))
            {
                //infos.ShowDialog();
                if (infos.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        clientBindingSource.Add(infos.ClientInfo);
                        db.Clients.Add(infos.ClientInfo);
                        await db.SaveChangesAsync();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void btn_GoBackMainMenu_Click_1(object sender, EventArgs e)
        {
            form_Main gobackmain = new form_Main();
            gobackmain.Show();
            this.Hide();
        }

        DbEntities db;
        
        private void form_Clients_Load(object sender, EventArgs e)
        {
            db = new DbEntities();
            clientBindingSource.DataSource = db.Clients.ToList();
            genderKindBindingSource.DataSource = db.GenderKinds.ToList();

            
            cboSearchCategories.SelectedIndex = 0;
        }

        //EDIT BUTTON
        private async void mtEdit_Click(object sender, EventArgs e)
        {
            Client obj = clientBindingSource.Current as Client;
            if (obj != null)
            {
                using (form_ClientsInfos infos = new form_ClientsInfos(obj))
                {
                    if (infos.ShowDialog() == DialogResult.OK)
                    {
                        try
                        {
                            clientBindingSource.EndEdit();
                            await db.SaveChangesAsync();
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
        }
        

        //DELETE BUTTON
        private void mtDelete_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure to Delete this Record?", "Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                int rows = dataGridView1.RowCount;
                for (int i = rows - 1; i >= 0; i--)
                {
                    if (dataGridView1.Rows[i].Selected)
                    {
                        db.Clients.Remove(dataGridView1.Rows[i].DataBoundItem as Client);
                        clientBindingSource.RemoveAt(dataGridView1.Rows[i].Index);
                    }
                }
            }
        }
        

        //SAVE BUTTON
        private async void Save_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Do want to Save the Changes?", "Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes) 
                {
                    clientBindingSource.EndEdit();
                    await db.SaveChangesAsync();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            form_ClientsTransactions tab1 = new form_ClientsTransactions();



                tab1.mtbox1.Text = this.dataGridView1.CurrentRow.Cells[0].Value.ToString();
                tab1.mtbox2.Text = this.dataGridView1.CurrentRow.Cells[1].Value.ToString();
                tab1.mtbox3.Text = this.dataGridView1.CurrentRow.Cells[2].Value.ToString();
                tab1.mtbox4.Text = this.dataGridView1.CurrentRow.Cells[3].Value.ToString();
                tab1.mtbox5.Text = this.dataGridView1.CurrentRow.Cells[4].Value.ToString();
                //tab1.mtbox6.Text = this.dataGridView1.CurrentRow.Cells[5].Value.ToString();
                //tab1.mtbox7.Text = this.dataGridView1.CurrentRow.Cells[6].Value.ToString();
                


            tab1.ShowDialog();
        }

        private void txtbxSeach_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Enter)
            {
                if (string.IsNullOrEmpty(txtbxSeach.Text))
                    clientBindingSource.Filter = string.Empty;
                else
                    clientBindingSource.Filter = string.Format("{0}='{1}'", cboSearchCategories.Text, txtbxSeach.Text);
            }
        }
    }
}
   