﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MaterialSkin;
using MaterialSkin.Animations;
using MaterialSkin.Controls;
using System.Threading;

namespace LMS_System_V1
{
    public partial class form_Login : MaterialSkin.Controls.MaterialForm
    {
        public form_Login()
        {
            InitializeComponent();
            MaterialSkin.MaterialSkinManager skinManager = MaterialSkin.MaterialSkinManager.Instance;
            skinManager.AddFormToManage(this);
            skinManager.Theme = MaterialSkin.MaterialSkinManager.Themes.LIGHT;
            skinManager.ColorScheme = new MaterialSkin.ColorScheme(MaterialSkin.Primary.Green600, MaterialSkin.Primary.BlueGrey900, MaterialSkin.Primary.BlueGrey500, MaterialSkin.Accent.Orange700, MaterialSkin.TextShade.WHITE);
        }

        private void form_Login_Load(object sender, EventArgs e)
        {
            statusStrip1.BackColor = Color.LightGreen;
        }

        private void txtbx_Username_MouseHover(object sender, EventArgs e)
        {
            toolStripStatusLabel1.Text = "Please Enter Valid Username.";
        }

        private void txtbx_Username_MouseLeave(object sender, EventArgs e)
        {
            toolStripStatusLabel1.Text = "";
        }

        private void txtbx_Password_MouseHover(object sender, EventArgs e)
        {
            toolStripStatusLabel1.Text = "Please Enter Valid Password.";
        }

        private void txtbx_Password_MouseLeave(object sender, EventArgs e)
        {
            toolStripStatusLabel1.Text = "";
        }

        private void btn_Login_MouseHover(object sender, EventArgs e)
        {
            toolStripStatusLabel1.Text = "Click here to Login.";
        }

        private void btn_Login_MouseLeave(object sender, EventArgs e)
        {
            toolStripStatusLabel1.Text = "";
        }

        private void btn_Exit_MouseHover(object sender, EventArgs e)
        {
            toolStripStatusLabel1.Text = "Click here to Exit.";
        }

        private void btn_Exit_MouseLeave(object sender, EventArgs e)
        {
            toolStripStatusLabel1.Text = "";
        }

        private void btn_Exit_Click(object sender, EventArgs e)
        {
            this.Close();
            Application.Exit();
        }

        private void btn_Login_Click(object sender, EventArgs e)
        {
           // string Username = "username1";
           // string Password = "password1";

           // if(Username == txtbx_Username.Text && Password == txtbx_Password.Text)
           // {
           //     form_Main main = new form_Main();
           //     main.Show();
           //     this.Hide();
           // }
           // else
           // {
           //     MessageBox.Show("Please Enter Valid Login Credentials!", "[ MESSAGE ]", MessageBoxButtons.RetryCancel, MessageBoxIcon.Stop);
           // }      

            if(string.IsNullOrEmpty(txtbx_Username.Text))
            {
                MessageBox.Show("Please Enter your Username.", "[ Message ]", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtbx_Username.Focus();
                return;
            }
            try
            {
                using(dblogincredentialsEntities log = new dblogincredentialsEntities())
                {
                    var query = from o in log.Users
                                where o.Username == txtbx_Username.Text && o.Password == txtbx_Password.Text
                                select o;
                    if(query.SingleOrDefault() != null)
                    {
                        MessageBox.Show("You have been Successfully Log In!", "[ Message ]", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        
                        form_Main main = new form_Main();
                        main.Show();
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("Your Login Credentials is Incorrect!", "[ Message ]", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "[ Message ]", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void txtbx_Username_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void txtbx_Password_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void chkbx_Show_Hide_Password_CheckedChanged(object sender, EventArgs e)
        {
            if(chkbx_Show_Hide_Password.Checked)
            {
                txtbx_Password.UseSystemPasswordChar = false;
            }
            else
            {
                txtbx_Password.UseSystemPasswordChar = true;
            }
        }
    }
}
