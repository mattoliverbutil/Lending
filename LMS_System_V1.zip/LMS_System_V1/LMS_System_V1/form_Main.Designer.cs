﻿namespace LMS_System_V1
{
    partial class form_Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Logout = new MaterialSkin.Controls.MaterialRaisedButton();
            this.btn_ViewClients = new MaterialSkin.Controls.MaterialRaisedButton();
            this.SuspendLayout();
            // 
            // btn_Logout
            // 
            this.btn_Logout.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_Logout.Depth = 0;
            this.btn_Logout.Location = new System.Drawing.Point(470, 338);
            this.btn_Logout.MouseState = MaterialSkin.MouseState.HOVER;
            this.btn_Logout.Name = "btn_Logout";
            this.btn_Logout.Primary = true;
            this.btn_Logout.Size = new System.Drawing.Size(117, 30);
            this.btn_Logout.TabIndex = 3;
            this.btn_Logout.Text = "Logout";
            this.btn_Logout.UseVisualStyleBackColor = true;
            this.btn_Logout.Click += new System.EventHandler(this.btn_Logout_Click);
            // 
            // btn_ViewClients
            // 
            this.btn_ViewClients.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_ViewClients.Depth = 0;
            this.btn_ViewClients.Location = new System.Drawing.Point(176, 176);
            this.btn_ViewClients.MouseState = MaterialSkin.MouseState.HOVER;
            this.btn_ViewClients.Name = "btn_ViewClients";
            this.btn_ViewClients.Primary = true;
            this.btn_ViewClients.Size = new System.Drawing.Size(251, 65);
            this.btn_ViewClients.TabIndex = 4;
            this.btn_ViewClients.Text = "[ View Clients ]";
            this.btn_ViewClients.UseVisualStyleBackColor = true;
            this.btn_ViewClients.Click += new System.EventHandler(this.btn_ViewClients_Click);
            // 
            // form_Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(599, 380);
            this.Controls.Add(this.btn_ViewClients);
            this.Controls.Add(this.btn_Logout);
            this.MaximizeBox = false;
            this.Name = "form_Main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "[ Main ]";
            this.Load += new System.EventHandler(this.form_Main_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private MaterialSkin.Controls.MaterialRaisedButton btn_Logout;
        private MaterialSkin.Controls.MaterialRaisedButton btn_ViewClients;
    }
}