﻿namespace LMS_System_V1
{
    partial class form_ClientsInfos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(form_ClientsInfos));
            this.txtEmailAddress = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.txtTelNo = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.txtClientAge = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel11 = new MetroFramework.Controls.MetroLabel();
            this.txtMiddleName = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.txtFirstName = new MetroFramework.Controls.MetroTextBox();
            this.txtLastName = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.btnSave = new MetroFramework.Controls.MetroButton();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.metroLabel8 = new MetroFramework.Controls.MetroLabel();
            this.cboGender = new MetroFramework.Controls.MetroComboBox();
            this.metroTextBox1 = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel9 = new MetroFramework.Controls.MetroLabel();
            this.ClientInfoPreviewDialog = new System.Windows.Forms.PrintPreviewDialog();
            this.ClientInfoPrintDocument = new System.Drawing.Printing.PrintDocument();
            this.btnPrint = new MetroFramework.Controls.MetroButton();
            this.btnPrintPreview = new MetroFramework.Controls.MetroButton();
            this.bindingSourceClient = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.bindingSourceClient)).BeginInit();
            this.SuspendLayout();
            // 
            // txtEmailAddress
            // 
            this.txtEmailAddress.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSourceClient, "EmailAddress", true));
            this.txtEmailAddress.Location = new System.Drawing.Point(168, 375);
            this.txtEmailAddress.Name = "txtEmailAddress";
            this.txtEmailAddress.Size = new System.Drawing.Size(333, 23);
            this.txtEmailAddress.TabIndex = 114;
            // 
            // metroLabel7
            // 
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.Location = new System.Drawing.Point(166, 353);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(92, 19);
            this.metroLabel7.TabIndex = 113;
            this.metroLabel7.Text = "Email Address";
            // 
            // txtTelNo
            // 
            this.txtTelNo.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSourceClient, "TelephoneNumber", true));
            this.txtTelNo.Location = new System.Drawing.Point(168, 323);
            this.txtTelNo.Name = "txtTelNo";
            this.txtTelNo.Size = new System.Drawing.Size(333, 23);
            this.txtTelNo.TabIndex = 112;
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.Location = new System.Drawing.Point(166, 301);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(121, 19);
            this.metroLabel6.TabIndex = 111;
            this.metroLabel6.Text = "Telephone Number";
            // 
            // txtClientAge
            // 
            this.txtClientAge.Location = new System.Drawing.Point(697, 266);
            this.txtClientAge.Name = "txtClientAge";
            this.txtClientAge.Size = new System.Drawing.Size(88, 23);
            this.txtClientAge.TabIndex = 110;
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.Location = new System.Drawing.Point(695, 244);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(33, 19);
            this.metroLabel5.TabIndex = 109;
            this.metroLabel5.Text = "Age";
            // 
            // metroLabel11
            // 
            this.metroLabel11.AutoSize = true;
            this.metroLabel11.Location = new System.Drawing.Point(695, 178);
            this.metroLabel11.Name = "metroLabel11";
            this.metroLabel11.Size = new System.Drawing.Size(84, 19);
            this.metroLabel11.TabIndex = 108;
            this.metroLabel11.Text = "Date of Birth";
            // 
            // txtMiddleName
            // 
            this.txtMiddleName.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSourceClient, "MiddleName", true));
            this.txtMiddleName.Location = new System.Drawing.Point(514, 140);
            this.txtMiddleName.Name = "txtMiddleName";
            this.txtMiddleName.Size = new System.Drawing.Size(162, 23);
            this.txtMiddleName.TabIndex = 107;
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.Location = new System.Drawing.Point(512, 118);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(90, 19);
            this.metroLabel4.TabIndex = 106;
            this.metroLabel4.Text = "Middle Name";
            // 
            // txtFirstName
            // 
            this.txtFirstName.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSourceClient, "FirstName", true));
            this.txtFirstName.Location = new System.Drawing.Point(339, 140);
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.Size = new System.Drawing.Size(162, 23);
            this.txtFirstName.TabIndex = 105;
            // 
            // txtLastName
            // 
            this.txtLastName.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSourceClient, "LastName", true));
            this.txtLastName.Location = new System.Drawing.Point(166, 140);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(162, 23);
            this.txtLastName.TabIndex = 104;
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(166, 178);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(56, 19);
            this.metroLabel3.TabIndex = 103;
            this.metroLabel3.Text = "Address";
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(337, 118);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(73, 19);
            this.metroLabel2.TabIndex = 102;
            this.metroLabel2.Text = "First Name";
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(166, 118);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(71, 19);
            this.metroLabel1.TabIndex = 101;
            this.metroLabel1.Text = "Last Name";
            // 
            // txtAddress
            // 
            this.txtAddress.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSourceClient, "Address", true));
            this.txtAddress.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddress.Location = new System.Drawing.Point(168, 200);
            this.txtAddress.Multiline = true;
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(508, 88);
            this.txtAddress.TabIndex = 100;
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(784, 435);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(136, 23);
            this.btnSave.TabIndex = 115;
            this.btnSave.Text = "&Save";
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(697, 200);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker1.TabIndex = 116;
            // 
            // metroLabel8
            // 
            this.metroLabel8.AutoSize = true;
            this.metroLabel8.Location = new System.Drawing.Point(689, 118);
            this.metroLabel8.Name = "metroLabel8";
            this.metroLabel8.Size = new System.Drawing.Size(52, 19);
            this.metroLabel8.TabIndex = 117;
            this.metroLabel8.Text = "Gender";
            // 
            // cboGender
            // 
            this.cboGender.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.bindingSourceClient, "GenderId", true));
            this.cboGender.FormattingEnabled = true;
            this.cboGender.ItemHeight = 23;
            this.cboGender.Location = new System.Drawing.Point(689, 140);
            this.cboGender.Name = "cboGender";
            this.cboGender.Size = new System.Drawing.Size(121, 29);
            this.cboGender.TabIndex = 118;
            // 
            // metroTextBox1
            // 
            this.metroTextBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSourceClient, "ClientId", true));
            this.metroTextBox1.Location = new System.Drawing.Point(166, 82);
            this.metroTextBox1.Name = "metroTextBox1";
            this.metroTextBox1.ReadOnly = true;
            this.metroTextBox1.Size = new System.Drawing.Size(510, 23);
            this.metroTextBox1.TabIndex = 120;
            // 
            // metroLabel9
            // 
            this.metroLabel9.AutoSize = true;
            this.metroLabel9.Location = new System.Drawing.Point(166, 60);
            this.metroLabel9.Name = "metroLabel9";
            this.metroLabel9.Size = new System.Drawing.Size(79, 19);
            this.metroLabel9.TabIndex = 119;
            this.metroLabel9.Text = "I.D. Number";
            // 
            // ClientInfoPreviewDialog
            // 
            this.ClientInfoPreviewDialog.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.ClientInfoPreviewDialog.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.ClientInfoPreviewDialog.ClientSize = new System.Drawing.Size(400, 300);
            this.ClientInfoPreviewDialog.Enabled = true;
            this.ClientInfoPreviewDialog.Icon = ((System.Drawing.Icon)(resources.GetObject("ClientInfoPreviewDialog.Icon")));
            this.ClientInfoPreviewDialog.Name = "ClientInfoPreviewDialog";
            this.ClientInfoPreviewDialog.Visible = false;
            // 
            // ClientInfoPrintDocument
            // 
            this.ClientInfoPrintDocument.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.ClientInfoPrintDocument_PrintPage);
            // 
            // btnPrint
            // 
            this.btnPrint.Location = new System.Drawing.Point(631, 435);
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Size = new System.Drawing.Size(136, 23);
            this.btnPrint.TabIndex = 121;
            this.btnPrint.Text = "&Print";
            // 
            // btnPrintPreview
            // 
            this.btnPrintPreview.Location = new System.Drawing.Point(480, 435);
            this.btnPrintPreview.Name = "btnPrintPreview";
            this.btnPrintPreview.Size = new System.Drawing.Size(136, 23);
            this.btnPrintPreview.TabIndex = 122;
            this.btnPrintPreview.Text = "&Print Preview";
            this.btnPrintPreview.Click += new System.EventHandler(this.btnPrintPreview_Click);
            // 
            // bindingSourceClient
            // 
            this.bindingSourceClient.DataSource = typeof(LMS_System_V1.Client);
            // 
            // form_ClientsInfos
            // 
            this.AcceptButton = this.btnSave;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(943, 481);
            this.Controls.Add(this.btnPrintPreview);
            this.Controls.Add(this.btnPrint);
            this.Controls.Add(this.metroTextBox1);
            this.Controls.Add(this.metroLabel9);
            this.Controls.Add(this.cboGender);
            this.Controls.Add(this.metroLabel8);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.txtEmailAddress);
            this.Controls.Add(this.metroLabel7);
            this.Controls.Add(this.txtTelNo);
            this.Controls.Add(this.metroLabel6);
            this.Controls.Add(this.txtClientAge);
            this.Controls.Add(this.metroLabel5);
            this.Controls.Add(this.metroLabel11);
            this.Controls.Add(this.txtMiddleName);
            this.Controls.Add(this.metroLabel4);
            this.Controls.Add(this.txtFirstName);
            this.Controls.Add(this.txtLastName);
            this.Controls.Add(this.metroLabel3);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.metroLabel1);
            this.Controls.Add(this.txtAddress);
            this.MaximizeBox = false;
            this.Name = "form_ClientsInfos";
            this.Text = "[ Client\'s Info ]";
            this.Load += new System.EventHandler(this.form_ClientsInfos_Load);
            ((System.ComponentModel.ISupportInitialize)(this.bindingSourceClient)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public MetroFramework.Controls.MetroTextBox txtEmailAddress;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        public MetroFramework.Controls.MetroTextBox txtTelNo;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        public MetroFramework.Controls.MetroTextBox txtClientAge;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroLabel metroLabel11;
        public MetroFramework.Controls.MetroTextBox txtMiddleName;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        public MetroFramework.Controls.MetroTextBox txtFirstName;
        public MetroFramework.Controls.MetroTextBox txtLastName;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        public System.Windows.Forms.TextBox txtAddress;
        private MetroFramework.Controls.MetroButton btnSave;
        private MetroFramework.Controls.MetroLabel metroLabel8;
        public MetroFramework.Controls.MetroTextBox metroTextBox1;
        private MetroFramework.Controls.MetroLabel metroLabel9;
        private System.Windows.Forms.BindingSource bindingSourceClient;
        public System.Windows.Forms.DateTimePicker dateTimePicker1;
        public MetroFramework.Controls.MetroComboBox cboGender;
        private System.Drawing.Printing.PrintDocument ClientInfoPrintDocument;
        private MetroFramework.Controls.MetroButton btnPrint;
        private MetroFramework.Controls.MetroButton btnPrintPreview;
        public System.Windows.Forms.PrintPreviewDialog ClientInfoPreviewDialog;

    }
}